#! /bin/sh

source /koolshare/scripts/base.sh
alias echo_date='echo 【$(TZ=UTC-8 date -R +%Y年%m月%d日\ %X)】:'

echo_date "====== 开始Crack Keyword ======"

sed -i 's/\tdetect_package/\t# detect_package/g' /koolshare/scripts/ks_tar_install.sh
sleep 1s

echo_date "=== Finsh，You Can Do Anything ==="
echo_date "=== 出走的图标，直接卸了就可以 ==="
echo_date 更新完毕，请等待网页自动刷新！
